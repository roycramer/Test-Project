var responseText1, responseText2, responseText3;
var questionText;
var chats, chatIndex;
var chatStateString = "";
var ready = false;
var errorText = "///";
var webText = "";
var bg;
//create the variables that need to exist throughout the game. score, various sprites, the game itself.






function createText(){

	var style = { font: 'Pacifico', fontSize: '25px', fill: '#FFF', stroke:'#000', strokeThickness:'5'};
    var styleBig = { font: 'Indie Flower', fontSize: '40px', fill: '#FFF', stroke:'#000', strokeThickness:'3', wordWrap: 'true', wordWrapWidth: '600' };
    var dist1 = 300;
    var dist2 = 45;
    questionText = game.add.text(30, 0, 'questionText', styleBig);
    responseText1 = game.add.text(30, dist1, 'responseText1', style);
    responseText2 = game.add.text(30, dist1+dist2, 'responseText2', style);
    responseText3 = game.add.text(30, dist1+dist2*2, 'responseText3', style);
   
    // var html = game.cache.getText('html');
    // var text = html.split('\n');    
    // extraText = game.add.text(30, dist1+dist2*3, 'extraText', style);
    // extraText.text = (text[0]);

    
    ready = true;
}

//graduate strike force
var gameLoopState = {
	create: function(){
		//change the background color and specify a keyboard.
		game.stage.backgroundColor = '#ffdafc';
		this.keyboard = game.input.keyboard;
		bg = game.add.sprite(32, game.world.height - 150, 'bg1');


		// (most of the code is from phaser tutorials and the 'first game' project.);

		game.physics.startSystem(Phaser.Physics.ARCADE);

		chats = new Array();
	    chats[0] = new chatChoice(game, "", "Where do you go? You should go to a place if you have a place to go to. Maybe you should go to a place which is a place", new Array("The Elevator", "The Checkout", "The Beds"), 'bg1');
	    chats[1] = new chatChoice(game, "a", "Which Floor?", new Array("1", "2", "3"), 'bg2');
	    chats[2] = new chatChoice(game, "b", "You see people. Do you run, hide, or pretend?", new Array("Run", "Hide", "Pretend"),'bg3');
	    chats[3] = new chatChoice(game, "c", "Do you jump on the bed or swing on the chandelier?", new Array("Jump on beds", "Swing on chandelier"), 'bg1');
	    chats[4] = new chatChoice(game, "aa", "Floor one is a thing.", new Array("go further"), 'bg1');
	    chats[5] = new chatChoice(game, "ab", "woop floor 2?", new Array("what's this?"), 'bg1');
	    chats[6] = new chatChoice(game, "ac", "woop floor 3?", new Array("1"), 'bg1');

	    
	    chatIndex = 0;
	    
	    game.time.events.add(Phaser.Timer.SECOND, createText, this);
	  
	},
	preload: function() {
	// preload assets
	//initialize the sprites by loading the files, for the spritesheet the resolution must be changed for baddies.\
    game.load.script('webfont', '//ajax.googleapis.com/ajax/libs/webfont/1.4.7/webfont.js');
    game.load.image('bg1', 'assets/img/bg1.jpg');
    game.load.image('bg2', 'assets/img/bg2.jpg');
    game.load.image('bg3', 'assets/img/bg3.jpg');
    // game.load.text('html', 'http://phaser.io');

	},
	update: function(){
		if(ready){
		    if ( game.input.keyboard.justPressed(Phaser.Keyboard.ONE) && responseText1.text!=errorText){
		    	chatStateString+="a";
		    }
		    if ( game.input.keyboard.justPressed(Phaser.Keyboard.TWO)  && responseText2.text!=errorText){
		    	chatStateString+="b";
		    }
		    if ( game.input.keyboard.justPressed(Phaser.Keyboard.THREE)  && responseText3.text!=errorText){
		    	chatStateString+="c";
		    }
		    if ( game.input.keyboard.justPressed(Phaser.Keyboard.R) ){
		    	chatStateString="";
		    }
		    for (var i = 0; i <chats.length; i++) {
		    	if(chatStateString.toUpperCase() == chats[i].stringID.toUpperCase()){
		    		chatIndex = i;
		    	}



		    }
		    bg.loadTexture(chats[chatIndex].bg);

		    var size = chats[chatIndex].ans.length;
		    questionText.text = chats[chatIndex].questionText;
		    console.log(chatStateString);
		    if(size>0){
		    	responseText1.text = "1)" + chats[chatIndex].ans[0];
		    }
		    else{
		    	responseText1.text = errorText;
		    }
		    if(size>1){
		    	responseText2.text = "2)" + chats[chatIndex].ans[1];
		    }
		    else{
		    	responseText2.text = errorText;
		    }
		    if(size>2){
		    	responseText3.text = "3)" + chats[chatIndex].ans[2];
		    }
		    else{
		    	responseText3.text = errorText;
		    }
		}
	    
	},
	
}
